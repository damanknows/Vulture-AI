"""Scanner package."""
